import { useState } from 'react'
import './App.css'
import cf from './game';

function App() {

   const [board, setBoard] = useState(cf.getBoard());
   const [selectedPiece, setSelectedPiece] = useState(0);
   const [turn, setTurn] = useState(cf.turn);
   const [winner, setWinner] = useState(null);

   const pieceCoords = new Array(7).fill(null);

   const selectPiece = (e, idx) => {
      e.preventDefault();
      e.stopPropagation();
      setSelectedPiece(idx);
   }

   const handleDrop = () => {
      const winner = cf.insertPiece([selectedPiece, 6]);
      setBoard([...cf.getBoard()]);

      if(winner){
         setWinner(winner.winner)
      } else{
         setTurn(cf.turn)
      }
   }

   return (
      <>
         <div className='main-container'>
            {winner ? <h1>{`The Winner is: Player ${winner}`}</h1>: null}
            <div
               className="piece-container"
               style={{display: 'flex', 'justifyContent': 'center', flexDirection: 'row', "gap": '30px'}}
            >
               {pieceCoords.map((el, idx) => (
                  <div
                     className={idx === selectedPiece ? `piece-active-${turn}`: `piece piece-${turn}`}
                     onClick={(e) => selectPiece(e, idx)}
                     key={`${idx}-${el}`}
                     >
                  </div>
               ))}
            </div>

               <div className='drop'>
                  <button onClick={handleDrop}>Drop</button>
               </div>

            <div className='game-container'>
               {board.map((col, idx) => (
                  <div
                  key={idx}
                     style={{ height: '10px', width: '10px' }}

                  >
                     {col.map((circle, idx) => (
                        <div
                           key={`${idx}-${circle}`}
                        >
                           {
                              circle === 0 ? <h1 className='circle-0'></h1>:
                              circle === 1? <h1 className='circle-1'></h1>:
                              <h1 className='circle-2'></h1>
                           }
                        </div>
                     ))}
                  </div>
               ))}
            </div>
         </div>
      </>

   )

}

export default App

class Game {
    constructor(){
        this.board = [
            [0, 0, 0, 0, 0, 0, 0], // 1
            [0, 0, 0, 0, 0, 0, 0], // 2
            [0, 0, 0, 0, 0, 0, 0], // 3
            [0, 0, 0, 0, 0, 0, 0], // 4
            [0, 0, 0, 0, 0, 0, 0], // 5
            [0, 0, 0, 0, 0, 0, 0], // 6
            [0, 0, 0, 0, 0, 0, 0], // 7
        ];
        //   a  b  c  d  e  f  g

        this.turn = 1; // p1 | p2
    }


    getBoard(){
        return this.board;
    }

    insertPiece(coord){
        const [row, col] = coord;
        if(this.isValidCoord(coord)){
            this.board[row][col] = this.turn;
            if(this.identifyWin(coord)){
                return {winner: this.turn}
            } else{
                this.changeTurn();
            }
        } else{
            const inserted = this.insertNext(coord);
            const [newR, newC] = inserted;
            if(inserted){
                if (this.identifyWin([newR, newC])) {
                    return { winner: this.turn }
                } else {
                    this.changeTurn();
                }
            } else {
                throw new Error("Can not place piece there")
            }
        }
    }

    changeTurn(){
        if(this.turn === 1){
            this.turn = 2;
        } else{
            this.turn = 1;
        }
    }

    insertNext(coord){
        let [row, col] = coord;
        if(this.board[row][col] === 0){
            this.board[row][col] = this.turn;
            return [row, col];
        }
        if(this.board[row][col] === undefined){
            return false;
        }
        if(this.board[row][col]){
            return this.insertNext([row, --col]);
        }
    }

    isValidCoord(coord){
        const [row, col] = coord;

        if(this.board[row][col] > 0 ){
            return false
        } else{
            return true;
        }
    }


    getHorNeighbors(coord){
        const [row, col] = coord;
        const neighbors = [
            //left
            [row -1, col],
            // right
            [row + 1, col]
        ];

        return neighbors.filter(neighbor => {
            const [row, col] = neighbor;
            return this.board[row] && this.board[row][col] === this.turn;
        });

    }
    getColNeighbors(coord){
        const [row, col] = coord;
        const neighbors = [
            //top
            [row, col + 1],
            // bottom
            [row, col -1]
        ];

        let currentNode = this.board[row][col];
        return neighbors.filter(neighbor => {
            const [row, col] = neighbor;
            return this.board[row] && this.board[row][col] === currentNode && currentNode === this.turn;
        })
    }

    // checks both left and right -> causes a bug. Should only traverse in one direction at a time.
    getDiagNeighbors(coord){
        const [row, col] = coord;
        const neighbors = [
            //top right
            [row - 1, col + 1],
            // top left
            [row + 1, col + 1]
        ];

        let currentNode = this.board[row][col];
        return neighbors.filter(neighbor => {
            const [row, col] = neighbor;
            return this.board[row] && this.board[row][col] === currentNode && currentNode === this.turn;
        })
    }



    horizontalTraversal(node, visited){
        const queue = [[node]];
        visited.add(`${node}`);
        let totalInARow = 1;

        while(queue.length){
            let path = queue.shift();
            let curr = path[path.length - 1];
            if(totalInARow === 4) return true;


            for(let neighbor of this.getHorNeighbors(curr)){
                if(!visited.has(`${neighbor}`)){
                    const [r,c] = neighbor;
                    if(this.board[r][c] === this.turn){
                        totalInARow++;
                    }
                    visited.add(`${neighbor}`);
                    queue.push([...path, neighbor]);
                }
            }

        }
        if(totalInARow >= 4) return true;
        return false;
    }
    verticalTraversal(node, visited){
        const queue = [[node]];
        visited.add(`${node}`);
        let totalInARow = 1;

        while(queue.length){
            let path = queue.shift();
            let curr = path[path.length - 1];
            if(path.length === 4){
                return true
            }
            if(totalInARow === 4) return true;

            for(let neighbor of this.getColNeighbors(curr)){
                if(!visited.has(`${neighbor}`)){
                    const [r, c] = neighbor;
                    if (this.board[r][c] === this.turn) {
                        totalInARow++;
                    }
                    visited.add(`${neighbor}`);
                    queue.push([...path, neighbor])
                }
            }

        }
        if(totalInARow >= 4) return true;
        return false;
    }
    diagonalTraversal(node, visited){
        const queue = [[node]];
        visited.add(`${node}`);
        let totalInARow = 1;

        while(queue.length){
            let path = queue.shift();
            let curr = path[path.length - 1];
            if(path.length === 4){
                return true
            }
            if(totalInARow === 4) return true;


            for(let neighbor of this.getDiagNeighbors(curr)){
                if(!visited.has(`${neighbor}`)){
                    const [r, c] = neighbor;
                    if (this.board[r][c] === this.turn) {
                        totalInARow++;
                    }
                    visited.add(`${neighbor}`);
                    queue.push([...path, neighbor])
                }
            }

        }
        if(totalInARow >= 4) return true;
        return false;
    }


    identifyWin(coords){
        const horizontal = new Set();
        if(this.horizontalTraversal(coords, horizontal)){
            return true;
        }
        const vertical = new Set();
        if(this.verticalTraversal(coords, vertical)){
            return true;
        }

        const diagonal = new Set();

        if(this.diagonalTraversal(coords, diagonal)){
            return true;
        }
    }

}

const cf = new Game();
export default cf;

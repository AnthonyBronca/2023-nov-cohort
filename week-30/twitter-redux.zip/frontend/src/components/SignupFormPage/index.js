import SignupFormPage from './SignupFormPage';

export default SignupFormPage;

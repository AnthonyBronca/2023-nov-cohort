import OpenModalButton from './OpenModalButton';

export default OpenModalButton;

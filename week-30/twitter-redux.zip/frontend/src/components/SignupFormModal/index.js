import SignupFormModal from './SignupFormModal';

export default SignupFormModal;

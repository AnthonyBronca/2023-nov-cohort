import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate, useParams } from 'react-router-dom';
import { deleteTweetThunk, updateTweetThunk } from '../../redux/tweets';

const Tweet = () => {

    const dispatch = useDispatch();
    const navigate = useNavigate();
    const { id } = useParams();
    const user = useSelector((state) => state.session.user);
    const tweet = useSelector((state) => state.tweetState.byId[id])

    const [updatedTweet, setUpdatedTweet] = useState(tweet.tweet);


    // step 2
    const handleUpdate = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        const updatedTweetForm = {
            user,
            updatedTweet,
            tweetId: id,
        };
        dispatch(updateTweetThunk(updatedTweetForm))
    }


    const handleDelete = async (e) => {
        e.preventDefault();
        e.stopPropagation();
        dispatch(deleteTweetThunk(tweet))
        navigate("/")

    }


    return (
        <div>
            <p>{tweet.tweet}</p>
            <p>User: {tweet.User.username}</p>
            <textarea
                type='text'
                value={updatedTweet}
                placeholder='Update Tweet'
                onChange={(e) => setUpdatedTweet(e.target.value)}
            />
            {
                user.id === tweet.User.id?
                <div>

                    <button
                        style={{ cursor: 'pointer' }}
                        onClick={(e)=> handleUpdate(e)}
                    >Update Tweet</button>
                    <button
                        style={{
                        backgroundColor: 'red',
                        color: 'white',
                        cursor: 'pointer'
                    }}
                    onClick={(e)=> handleDelete(e)}
                    >Delete Tweet</button>
                </div>
                : null
                }
    </div>
    );
}

export default Tweet;

import React, { useEffect, useState } from 'react';
import {useDispatch, useSelector} from 'react-redux'
import { getTweetsThunk, postTweetThunk } from '../../redux/tweets';
import { useNavigate } from 'react-router-dom';

const Splash = () => {

  const dispatch = useDispatch();
  const navigate = useNavigate();
  // step 8
  const tweets = useSelector((state)=> state.tweetState.allTweets);
  const user = useSelector((state)=> state.session.user);



  const [isLoaded, setIsLoaded] = useState(false);
  const [newTweet, setNewTweet] = useState("");
  const [errors, setErrors] = useState({});


  useEffect(()=> {

    // step 2
    const getData = async() => {
      // grab data from backend
        dispatch(getTweetsThunk());
        setIsLoaded(true);
      }

      // we are not loaded
      if(!isLoaded && !tweets.length){
        getData()
    }

  }, [dispatch, isLoaded])
  // step 2
  const handleButtonClick = async() => {
    const form = {
      user,
      newTweet
    }

    const res = await dispatch(postTweetThunk(form));
    if(!res.ok){
      const err = await res.json();
      const backendErrors = {};
      backendErrors.message = err.message;
      setErrors(backendErrors);
    }

  }


  const goToTweet = (e, tweet) => {
    e.preventDefault();
    e.stopPropagation();
    navigate(`/tweets/${tweet.id}`)
  }

  if(!isLoaded){
    setTimeout(()=> {
    return <img
      src="https://media.tenor.com/On7kvXhzml4AAAAj/loading-gif.gif"
      alt="loading animation"
      style={{height: '30px', width: '30px'}}
      />
    }, 1000
    )
  }
  return (
    <div style={{position: 'relative', top: '2rem'}}>
        <h1>Welcome To Twitter</h1>
        <div style={{border: '1px black solid', padding: '20px'}}>
          <input
            type="text"
            placeholder='New Tweet'
            value={newTweet}
            onChange={(e)=> setNewTweet(e.target.value)}
            />
        <button style={{
          backgroundColor: "rgb(29,155,240)",
          color: 'white',
          cursor: 'pointer' }}
          onClick={()=> handleButtonClick()}
          >Submit Tweet</button>
        </div>
        {errors.message ? <span style={{color: 'red'}}>{errors.message}</span>: null}
        {tweets.map((tweet, idx)=> (
          <div
           key={`${idx}-${tweet.id}`}
           style={{
            border: '1px solid black',
            cursor: 'pointer'
            }}
            onClick={(e)=> goToTweet(e, tweet)}
            >
            <div style={{display: 'flex', flexDirection: 'row', alignItems: 'center', gap: '10px'}}>
              <p>{tweet.tweet}</p>
              <span>{tweet.User.username}</span>
            </div>
          </div>
        ))}
    </div>
  );
}

export default Splash;

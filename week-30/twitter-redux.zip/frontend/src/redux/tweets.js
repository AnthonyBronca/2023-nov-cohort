import {csrfFetch} from './csrf';


// CONSTANTS
const GET_ALL_TWEETS = "tweets/getAllTweets";
const POST_TWEET = "tweets/postTweet";
const UPDATE_TWEET = "tweets/updateTweet";
const DELETE_TWEET = "tweets/deleteTweet";


// ACTION CREATORS
const getAllTweets = (tweets) => ({
    type: GET_ALL_TWEETS,
    payload: tweets
});

const postTweet = (tweet) => ({
    type: POST_TWEET,
    payload: tweet
});

const updateTweet = (updatedTweet) => ({
    type: UPDATE_TWEET,
    payload: updatedTweet
});

const deleteTweet = (deletedTweet) => ({
    type: DELETE_TWEET,
    payload: deletedTweet
});

// THUNKS
export const deleteTweetThunk = (tweet) => async(dispatch) => {
    try {
            console.log("step 3", tweet);
            const options = {
                method: 'DELETE',
                header: {'Content-Type': 'application/json'},
                body: JSON.stringify(tweet)
            };

            const res = await csrfFetch(`/api/tweets/${tweet.id}`, options);
            // console.log(res, "this is res")
            if(res.ok){
                const data = await res.json();
                dispatch(deleteTweet(data));

            } else{
                throw res;
            }

    } catch (error) {
        return error;
    }
}


export const updateTweetThunk = (tweetForm) => async(dispatch) => {
    try {
        // console.log("we are in step 3");

        const options = {
            method: 'PUT',
            header: {'Content-Type': 'application/json'},
            body: JSON.stringify(tweetForm)
        }

        const res = await csrfFetch(`/api/tweets/${tweetForm.tweetId}`, options)
        if(res.ok){
            // step 5
            const data = await res.json();
            data.User = tweetForm.user
            dispatch(updateTweet(data))

        } else{
            throw res;
        }
    } catch (error) {
        return error;
    }
}


function sayHi(){
    return "hi"
};



export const postTweetThunk = (tweetForm) => async(dispatch) => {
    try {
        // console.log("step 3", tweetForm)
        const options = {
            method: 'POST',
            header: {'Content-Type': 'application/json'},
            body: JSON.stringify(tweetForm)
        }

        const res = await csrfFetch('/api/tweets', options);

        if(res.ok){
            // step 5
            const data = await res.json();
            data.User = tweetForm.user;
            dispatch(postTweet(data));
        } else{
            throw res;
        }

    } catch (error) {
        return error;
    }
}




// THUNKS
export const getTweetsThunk = () => async(dispatch) => {
    try {
        // console.log("we are in step 3")
        const res = await csrfFetch('/api/tweets');
        if(res.ok){
            // step 5
            // console.log("we are in step 5")
            const data = await res.json();
            dispatch(getAllTweets(data))

        } else{
            throw res;
        }
    } catch (error) {
        return error;
    }
}


// REDUCER

const initialState = {
    allTweets: [],
    byId : {}
}

function tweetsReducer(state = initialState, action) {
    let newState;
    switch (action.type) {
        case DELETE_TWEET:
            newState = {...state};

            console.log(action.payload)


            const filteredTweets = newState.allTweets.filter((tweet)=> {
             return tweet.id !== action.payload.id
            })
            newState.allTweets = filteredTweets



            const newById = {...newState.byId};
            delete newById[action.payload.id];
            newState.byId = newById;



            return newState;



        case UPDATE_TWEET:
            newState = {...state};
            // console.log("we are in step 7")
            const tweetId = action.payload.id;

            const newAllTweets = [];

            for(let i = 0; i < newState.allTweets.length; i++){
                let currtweet = newState.allTweets[i];
                if(currtweet.id === tweetId){
                    newAllTweets.push(action.payload);
                } else{
                    newAllTweets.push(currtweet)
                }
            }

            newState.allTweets = newAllTweets;
            newState.byId = {...newState.byId, [tweetId]: action.payload};
             return newState;
        case GET_ALL_TWEETS:
            newState = {...state};
            // builds out the allTweets
            newState.allTweets = action.payload;

            // builds out the byId
            for(let tweet of action.payload){
                newState.byId[tweet.id] = tweet;
            }
            return newState;
        case POST_TWEET:
            newState = {...state};
            // console.log(action.payload)
            // change my allTweets
            newState.allTweets = [action.payload, ...newState.allTweets];
            // change my byId
            newState.byId = {...newState.byId, [action.payload.id]: action.payload}

            return newState
        default:
            return state;
    }
}

export default tweetsReducer

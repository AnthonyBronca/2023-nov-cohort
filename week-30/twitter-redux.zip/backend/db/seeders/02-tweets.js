'use strict';

const { Tweet, Sequelize } = require('../models');
const bcrypt = require('bcryptjs');


let options = {};
options.tableName = 'Tweets';

if (process.env.NODE_ENV === 'production') {
    options.schema = process.env.SCHEMA;
}

module.exports = {


    up: async (queryInterface, Sequelize) => {
        options.tableName = "Tweets";
        return queryInterface.bulkInsert(options, [
            {
                tweet: 'Hello I am the first tweet',
                userId: 1
            },
            {
                tweet: 'I am the 2nd tweet',
                userId: 2
            },
            {
                tweet: 'Did you all go see that new movie that just came out? It was awesome!',
                userId: 3
            },
            {
                tweet: 'This is another tweet',
                userId: 1
            },

        ], {})
    },



    down: async (queryInterface, Sequelize) => {
        options.tableName = "Tweets";
        const Op = Sequelize.Op;
        return queryInterface.bulkDelete(options, {
            username: { [Op.in]: [] }
        })
    }
}

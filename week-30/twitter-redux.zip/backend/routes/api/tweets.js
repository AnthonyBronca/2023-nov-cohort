const express = require('express');
const { setTokenCookie, requireAuth } = require('../../utils/auth');
const { User, Tweet } = require('../../db/models');

const router = express.Router();


router.delete('/:id', requireAuth, async (req, res, next) => {
    try {
        const { id } = req.params;

        const existingTweet = await Tweet.findByPk(id);
        if (!existingTweet) {
            throw new Error("404, cant find it man");
        } else {
            await existingTweet.destroy();
            return res.json(existingTweet);
        }


    } catch (error) {
        next(error);
    }
})

router.put('/:id', requireAuth, async (req, res, next) => {
    try {
        const { id } = req.params;
        const body = req.body;


        const existingTweet = await Tweet.findByPk(id);
        if (!existingTweet) {
            throw new Error("404 cant find that");
        } else if (body.user.id === existingTweet.userId.dataValues) {
            throw new Error("403, you dont have acces to do this...")
        } else {
            const updatedTweet = await existingTweet.update({
                tweet: body.updatedTweet,
                userId: body.user.id
            })
            return res.json(updatedTweet)
        }
    } catch (error) {
        next(error);
    }
})

router.post('/', async (req, res, next) => {
    try {


        const { user, newTweet } = req.body;

        if (!newTweet) {
            throw new Error("Tweet can not be empty Hello PST PEEPS");
        } else {
            const tweet = await Tweet.create({
                tweet: newTweet,
                userId: user.id
            });

            return res.json(tweet);
        }


    } catch (error) {
        next(error);
    }
})


router.get('/', async (_req, res, next) => {
    try {
        console.log("we are in step 4");
        const tweets = await Tweet.findAll({
            include: {
                model: User
            }
        }); // returns an array of all tweets
        return res.json(tweets.reverse());
    } catch (error) {
        next(error);
    }
})

module.exports = router;
